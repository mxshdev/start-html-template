initFormUiModule();

function initFormUiModule() {
	
	$body.on('click', '.ui.form label, .ui.form .label', function() {
		$(this).next().focus();
	});
	
	$body.on('click', 'label', function() {
		$(this).next().focus();
	});
	
}