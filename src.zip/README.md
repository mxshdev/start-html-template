# start-html
Start HTML Template.
# How start
1. git clone https://github.com/Shmasya/start-html-template/
2. cd start-html
3. npm i
4. bower i
5. gulp
6. localhost:3000
